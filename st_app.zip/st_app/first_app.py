import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import seaborn as sns
from PIL import Image
#import bar_chart_race as bcr

st.set_option('deprecation.showPyplotGlobalUse', False)
st_folder = 'st_app_solution'

page = st.sidebar.radio("Navigation", ["Data", "About me"])

uploaded_file = st.sidebar.file_uploader("Choose a JSON file")

if uploaded_file is not None:
    df = pd.read_json(uploaded_file)
else:
    df = pd.read_json("Historique des recherches.json")

os.makedirs(st_folder, exist_ok=True)
print(st_folder)

if page=="Data":
    df['time'] = df.time.map(pd.to_datetime)
    df['time'] = df.time.dt.tz_convert('UTC').dt.tz_convert('Etc/GMT-2') #pytz.all_timezones

    #Functions
    def get_day(dt):
        return dt.day

    def get_year(dt):
        return dt.year

    def get_month(dt):
        return dt.month

    def get_hour(dt):
        return dt.hour

    def get_minute(dt):
        return dt.minute

    def get_weekday(dt):
        return dt.weekday()

    #Executions
    df['day'] = df['time'].map(get_day)
    df['year'] = df['time'].map(get_year)
    df['month'] = df['time'].map(get_month)
    df['weekday'] = df['time'].map(get_weekday)
    df['hour'] = df['time'].map(get_hour)
    df['minute'] = df['time'].map(get_minute)

    #Masks
    df_2016 = df.year<2017
    df_2017 = (df.year<2018) & (df.year>2016)
    df_2018 = (df.year<2019) & (df.year>2017)
    df_2019 = (df.year<2020) & (df.year>2018)
    df_2020 = (df.year<2021) & (df.year>2019)
    df_2021 = df.year>2020

    df_2016 = df[df_2016]
    df_2017 = df[df_2017]
    df_2018 = df[df_2018]
    df_2019 = df[df_2019]
    df_2020 = df[df_2020]
    df_2021 = df[df_2021]

    add_selectbox_choice = st.sidebar.selectbox(
        "What do you want to see",
        ("Analysis", "Interpretation","Conclusion")
    )

    add_selectbox_year = st.sidebar.selectbox(
        "Which year do you want to see",
        ("2021", "2020", "2019", "2018", "2017", "2016", "All")
    )


    add_selectbox_month = st.sidebar.selectbox(
        "Which month do you want to see",
        ("January", "February","March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    )

    def count_rows(rows):
        return len(rows)

    #Avoir les jours de la semaine plus facilement
    def which_day(day):
        jour = ""
        if(day==6):
            jour="Dimanche"
        if(day==5):
            jour="Samedi"
        if(day==4):
            jour="Vendredi"
        if(day==3):
            jour="Jeudi"
        if(day==2):
            jour="Mercredi"
        if(day==1):
            jour="Mardi"
        if(day==0):
            jour="Lundi"
        return jour

    st.title('YouTube analysis of my own data')
    st.title('Gwet 2021')
    st.title('Linkedin : Karis Gwet')
    st.title('Github : /KarisG')
    if(add_selectbox_choice=="Analysis"):
        if(add_selectbox_year=="2021"):
            col1, col2, col3 = st.columns(3)
            col1.metric("researches ",len(df_2021.time.value_counts()))
            col2.metric("Last year", len(df_2020.time.value_counts()), str(-int(len(df_2020.time.value_counts())-len(df_2021.time.value_counts()))/int(len(df_2020.time.value_counts()))*100)+"%")
            col3.metric("Since 2016", len(df_2016.time.value_counts()), str(-int(len(df_2016.time.value_counts())-len(df_2021.time.value_counts()))/int(len(df_2016.time.value_counts()))*100)+"%")

            plt.rcParams["figure.figsize"] = [7.50, 3.50]
            plt.rcParams["figure.autolayout"] = True

            plt.plot(df_2021.day.value_counts().sort_index(), color='yellow', label="2021")
            plt.xticks(np.arange(1, 32))
            plt.xlabel("Day")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2021")
            plt.legend()
            st.pyplot()

            st.info("There we can see my consumption in 2021 per day. I regrouped every first day, second day until 31th of 2021 to see the evolution throught the year")
            plt.rcParams["figure.autolayout"] = False

            mv_2021 = df_2021.title.value_counts() > 21
            mv_2021 = mv_2021[mv_2021 == True]
            mv_2021_times = list(df_2021.title.value_counts())
            mv_2021_times = mv_2021_times[0:5]
            mv_2021_title = ["Anime Reaction", "US Music", "FR Music", "Manga", "School"]

            plt.bar(np.arange(0, 7), df_2021.weekday.value_counts().sort_index(), label="2021", color='yellow')
            plt.xlabel("Day of the week")
            plt.ylabel("Number of researches")
            plt.title("Frequency of YouTube researches per week in 2021")
            plt.xticks(range(0, 7), "Mon Tue Wed Thur Fri Sat Sun".split())
            plt.legend()
            st.pyplot()
            st.info("Here we can see my consumption of YouTube data per week in 2021. I counted all researches  done day by day and we can see that friday is the day where I go often on YouTube with "+str(df_2021.weekday.value_counts().max())+" researches ")

            myexplode = [0.2, 0, 0, 0, 0]
            plt.figure(0)
            arialfont = {'fontname': 'Cambria',
                         'weight': 'bold',
                         'size': 22}
            plt.pie(mv_2021_times, labels=mv_2021_title, explode=myexplode, shadow=True, radius=2, autopct='%1.1f%%')
            plt.text(2.5, -1.75, "Most viewed videos by category in 2021", **arialfont)
            st.pyplot()
            if(add_selectbox_month=="January"):
                st.success("January")
                df_2021_month = df_2021[df_2021.month == 1]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="February"):
                st.success("February")
                df_2021_month = df_2021[df_2021.month == 2]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="March"):
                st.success("March")
                df_2021_month = df_2021[df_2021.month == 3]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="April"):
                st.success("April")
                df_2021_month = df_2021[df_2021.month == 4]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="May"):
                st.success("May")
                df_2021_month = df_2021[df_2021.month == 5]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="June"):
                st.success("June")
                df_2021_month = df_2021[df_2021.month == 6]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="July"):
                st.success("July")
                df_2021_month = df_2021[df_2021.month == 7]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="August"):
                st.success("August")
                df_2021_month = df_2021[df_2021.month == 8]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="September"):
                st.success("September")
                df_2021_month = df_2021[df_2021.month == 9]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2021_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2021_month.hour.value_counts().sort_index())

        elif(add_selectbox_year=="2020"):
            col1, col2, col3 = st.columns(3)
            col1.metric("researches ",len(df_2020.time.value_counts()))
            col2.metric("Last year", len(df_2019.time.value_counts()), str(-int(len(df_2019.time.value_counts())-len(df_2020.time.value_counts()))/int(len(df_2019.time.value_counts()))*100)+"%")
            col3.metric("Since 2016", len(df_2016.time.value_counts()), str(-int(len(df_2016.time.value_counts())-len(df_2020.time.value_counts()))/int(len(df_2016.time.value_counts()))*100)+"%")

            plt.rcParams["figure.figsize"] = [7.50, 3.50]
            plt.rcParams["figure.autolayout"] = True

            plt.plot(df_2020.day.value_counts().sort_index(), color='gray', label="2020")
            plt.xticks(np.arange(1, 32))
            plt.xlabel("Day")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2020")
            plt.legend()
            st.pyplot()

            plt.bar(np.arange(0, 7), df_2020.weekday.value_counts().sort_index(), label="2020", color='gray')
            plt.xlabel("Day of the week")
            plt.ylabel("Number of researches")
            plt.title("Frequency of YouTube researches per week in 2020")
            plt.xticks(range(0, 7), "Mon Tue Wed Thur Fri Sat Sun".split())
            plt.legend()
            st.pyplot()

            st.info("Here we can see my consumption of YouTube data per week in 2020. I counted all researches  done day by day and we can see that wednesday is the day where I go often on YouTube with "+str(df_2020.weekday.value_counts().max())+" researches ")
            plt.rcParams["figure.autolayout"] = False

            myexplode = [0.2, 0, 0, 0]
            plt.figure(0)
            mv_2020 = df_2020.title.value_counts() > 3
            mv_2020 = mv_2020[mv_2020==True]
            mv_2020_times = list(df_2020.title.value_counts())
            mv_2020_times = mv_2020_times[0:4]
            mv_2020_title = ["US Music","FR Music","Anime Reaction","School"]
            arialfont = {'fontname': 'Cambria',
                         'weight': 'bold',
                         'size': 22}
            plt.pie(mv_2020_times, labels=mv_2020_title, explode=myexplode, shadow=True, radius=2, autopct='%1.1f%%')
            plt.text(2.5, -1.75, "Most viewed videos by category in 2020", **arialfont)
            st.pyplot()

            if (add_selectbox_month == "January"):
                st.success("January")
                df_2020_month = df_2020[df_2020.month == 1]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "February"):
                st.success("February")
                df_2020_month = df_2020[df_2020.month == 2]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "March"):
                st.success("March")
                df_2020_month = df_2020[df_2020.month == 3]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "April"):
                st.success("April")
                df_2020_month = df_2020[df_2020.month == 4]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "May"):
                st.write("May")
                df_2020_month = df_2020[df_2020.month == 5]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "June"):
                st.success("June")
                df_2020_month = df_2020[df_2020.month == 6]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "July"):
                st.success("July")
                df_2020_month = df_2020[df_2020.month == 7]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "August"):
                st.success("August")
                df_2020_month = df_2020[df_2020.month == 8]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "September"):
                st.success("September")
                df_2020_month = df_2020[df_2020.month == 9]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "October"):
                st.success("October")
                df_2020_month = df_2020[df_2020.month == 10]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "November"):
                st.success("November")
                df_2020_month = df_2020[df_2020.month == 11]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
            if (add_selectbox_month == "December"):
                st.success("December")
                df_2020_month = df_2020[df_2020.month == 12]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2020_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2020_month.hour.value_counts().sort_index())
        elif(add_selectbox_year=="2019"):
            col1, col2, col3 = st.columns(3)
            col1.metric("researches ",len(df_2019.time.value_counts()))
            col2.metric("Last year", len(df_2018.time.value_counts()), str(-int(len(df_2018.time.value_counts())-len(df_2019.time.value_counts()))/int(len(df_2018.time.value_counts()))*100)+"%")
            col3.metric("Since 2016", len(df_2016.time.value_counts()), str(-int(len(df_2016.time.value_counts())-len(df_2019.time.value_counts()))/int(len(df_2016.time.value_counts()))*100)+"%")

            plt.rcParams["figure.figsize"] = [7.50, 3.50]
            plt.rcParams["figure.autolayout"] = True

            plt.plot(df_2019.day.value_counts().sort_index(), color='green', label="2019")
            plt.xticks(np.arange(1, 32))
            plt.xlabel("Day")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2019")
            plt.legend()
            st.pyplot()

            plt.bar(np.arange(0, 7), df_2019.weekday.value_counts().sort_index(), label="2019", color='green')
            plt.xlabel("Day of the week")
            plt.ylabel("Number of researches")
            plt.title("Frequency of YouTube researches per week in 2019")
            plt.xticks(range(0, 7), "Mon Tue Wed Thur Fri Sat Sun".split())
            plt.legend()
            st.pyplot()
            st.info("Here we can see my consumption of YouTube data per week in 2019. I counted all researches  done day by day and we can see that saturday is the day where I go often on YouTube with "+str(df_2019.weekday.value_counts().max())+" researches ")
            plt.rcParams["figure.autolayout"] = False

            mv_2019 = df_2019.title.value_counts() >= 3
            mv_2019 = mv_2019[mv_2019 == True]
            mv_2019_times = list(df_2019.title.value_counts())
            mv_2019_times = mv_2019_times[0:4]
            mv_2019_title = ["Manga", "Anime Reaction", "American Entertainment", "School"]
            arialfont = {'fontname': 'Cambria',
                         'weight': 'bold',
                         'size': 22}
            myexplode = [0.2, 0, 0, 0]
            plt.figure(0)
            plt.pie(mv_2019_times, labels=mv_2019_title, explode=myexplode, shadow=True, radius=2, autopct='%1.1f%%')
            plt.text(2.5, -1.75, "Most viewed videos by category in 2019", **arialfont)
            st.pyplot()
            if(add_selectbox_month=="March"):
                st.success("March")
                df_2019_month = df_2019[df_2019.month == 3]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="April"):
                st.success("April")
                df_2019_month = df_2019[df_2019.month == 4]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="May"):
                st.write("May")
                df_2019_month = df_2019[df_2019.month == 5]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="June"):
                st.success("June")
                df_2019_month = df_2019[df_2019.month == 6]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="August"):
                st.success("August")
                df_2019_month = df_2019[df_2019.month == 8]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="September"):
                st.success("September")
                df_2019_month = df_2019[df_2019.month == 9]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="October"):
                st.success("October")
                df_2019_month = df_2019[df_2019.month == 10]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="November"):
                st.success("November")
                df_2019_month = df_2019[df_2019.month == 11]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="December"):
                st.success("December")
                df_2019_month = df_2019[df_2019.month == 12]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2019_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2019_month.hour.value_counts().sort_index())

        elif(add_selectbox_year=="2018"):
            col1, col2, col3 = st.columns(3)
            col1.metric("researches ",len(df_2018.time.value_counts()))
            col2.metric("Last year", len(df_2017.time.value_counts()), str(-int(len(df_2017.time.value_counts())-len(df_2016.time.value_counts()))/int(len(df_2017.time.value_counts()))*100)+"%")
            col3.metric("Since 2016", len(df_2016.time.value_counts()), str(-int(len(df_2016.time.value_counts())-len(df_2018.time.value_counts()))/int(len(df_2016.time.value_counts()))*100)+"%")

            plt.rcParams["figure.figsize"] = [7.50, 3.50]
            plt.rcParams["figure.autolayout"] = True

            plt.plot(df_2018.day.value_counts().sort_index(), color='brown', label="2018")
            plt.xticks(np.arange(1, 32))
            plt.xlabel("Day")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2018")
            plt.legend()
            st.pyplot()

            plt.bar(np.arange(0, 7), df_2018.weekday.value_counts().sort_index(), label="2018", color='brown')
            plt.xlabel("Day of the week")
            plt.ylabel("Number of researches")
            plt.title("Frequency of YouTube researches per week in 2018")
            plt.xticks(range(0, 7), "Mon Tue Wed Thur Fri Sat Sun".split())
            plt.legend()
            st.pyplot()

            st.info("Here we can see my consumption of YouTube data per week in 2018. I counted all researches  done day by day and we can see that saturday is the day where I go often on YouTube with "+str(df_2018.weekday.value_counts().max())+" researches ")
            plt.rcParams["figure.autolayout"] = False

            arialfont = {'fontname': 'Cambria',
                         'weight': 'bold',
                         'size': 22}
            mv_2018 = df_2018.title.value_counts() >= 2
            mv_2018 = mv_2018[mv_2018 == True]
            mv_2018_times = list(df_2018.title.value_counts())
            mv_2018_times = mv_2018_times[0:4]
            mv_2018_title = ["American Entertainment", "School", "English improvement", "US Music"]
            myexplode = [0.2, 0, 0, 0]
            plt.figure(0)
            plt.pie(mv_2018_times, labels=mv_2018_title, explode=myexplode, shadow=True, radius=2, autopct='%1.1f%%')
            plt.text(2.5, -1.75, "Most viewed videos by category in 2018", **arialfont)
            st.pyplot()
            if(add_selectbox_month=="April"):
                st.success("April")
                df_2018_month = df_2018[df_2018.month == 4]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2018_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2018_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="May"):
                st.write("May")
                df_2018_month = df_2018[df_2018.month == 5]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2018_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2018_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="June"):
                st.success("June")
                df_2018_month = df_2018[df_2018.month == 6]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2018_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2018_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="August"):
                st.success("August")
                df_2018_month = df_2018[df_2018.month == 8]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2018_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2018_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="September"):
                st.success("September")
                df_2018_month = df_2018[df_2018.month == 9]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2018_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2018_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="October"):
                st.success("October")
                df_2018_month = df_2018[df_2018.month == 10]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2018_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2018_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="November"):
                st.success("November")
                df_2018_month = df_2018[df_2018.month == 11]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2018_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2018_month.hour.value_counts().sort_index())
            if(add_selectbox_month=="December"):
                st.success("December")
                df_2018_month = df_2018[df_2018.month == 12]
                st.caption("                                    Consumption in a month")
                st.line_chart(df_2018_month.day.value_counts().sort_index())
                st.caption("                                    Consumption per hour")
                st.bar_chart(df_2018_month.hour.value_counts().sort_index())

        elif(add_selectbox_year=="2017"):
            col1, col2 = st.columns(2)
            col1.metric("researches ",len(df_2017.time.value_counts()))
            col2.metric("Last year", len(df_2016.time.value_counts()), str(-int(len(df_2016.time.value_counts())-len(df_2017.time.value_counts()))/int(len(df_2016.time.value_counts()))*100)+"%")

            plt.rcParams["figure.figsize"] = [7.50, 3.50]
            plt.rcParams["figure.autolayout"] = True

            plt.plot(df_2017.day.value_counts().sort_index(), color='red', label="2017")
            plt.xticks(np.arange(1, 32))
            plt.xlabel("Day")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2017")
            plt.legend()
            st.pyplot()

            plt.bar(np.arange(0, 6), df_2017.weekday.value_counts().sort_index(), label="2017", color='red')
            plt.xlabel("Day of the week")
            plt.ylabel("Number of researches")
            plt.title("Frequency of YouTube researches per week in 2017")
            plt.xticks(range(0, 7), "Mon Tue Wed Thur Fri Sat Sun".split())
            plt.legend()
            st.pyplot()
            st.info("Here we can see my consumption of YouTube data per week in 2017. I counted all researches  done day by day and we can see that thursday is the day where I go often on YouTube with "+str(df_2017.weekday.value_counts().max())+" researches ")
            plt.rcParams["figure.autolayout"] = False

            arialfont = {'fontname': 'Cambria',
                         'weight': 'bold',
                         'size': 22}
            mv_2017 = df_2017.title.value_counts() == 1
            mv_2017 = mv_2017[mv_2017 == True]
            mv_2017_times = list(df_2017.title.value_counts())
            mv_2017_times = mv_2017_times[0:4]
            mv_2017_title = ["US Music", "School", "Games", "Basketball"]
            myexplode = [0.2, 0, 0, 0]
            plt.figure(0)
            plt.pie(mv_2017_times, labels=mv_2017_title, explode=myexplode, shadow=True, radius=2, autopct='%1.1f%%');
            plt.text(2.5, -1.75, "Most viewed videos by category in 2017", **arialfont);
            st.pyplot()

        elif(add_selectbox_year=="2016"):

            plt.rcParams["figure.figsize"] = [7.50, 3.50]
            plt.rcParams["figure.autolayout"] = True

            st.write("There we can see my consumption in 2016 per day. I regrouped every first day, second day until 31th of 2021 to see the evolution throught the year")
            plt.plot(df_2016.day.value_counts().sort_index(), color='blue', label="2016")
            plt.xticks(np.arange(1, 32))
            plt.xlabel("Day")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2016")
            plt.legend()
            st.pyplot()

            plt.bar(np.arange(0, 5), df_2016.weekday.value_counts().sort_index(), label="2016", color='blue')
            plt.xlabel("Day of the week")
            plt.ylabel("Number of researches")
            plt.title("Frequency of YouTube researches per week")
            plt.xticks(range(0, 7), "Mon Tue Wed Thur Fri Sat Sun".split())
            plt.legend()
            st.pyplot()
            st.info("Here we can see my consumption of YouTube data per week in 2016. I counted all researches  done day by day and we can see that thursday is the day where I go often on YouTube with "+str(df_2016.weekday.value_counts().max())+" researches ")

            plt.rcParams["figure.autolayout"] = False

            arialfont = {'fontname': 'Cambria',
                         'weight': 'bold',
                         'size': 22}
            df_2016.title.value_counts()
            mv_2016 = df_2016.title.value_counts() == 1
            mv_2016 = mv_2016[mv_2016 == True]
            mv_2016_times = list(df_2016.title.value_counts())
            mv_2016_times = mv_2016_times[0:4]
            mv_2016_title = ["Anime", "Games", "Japan Music", "Basketball"]
            myexplode = [0.2, 0, 0, 0]
            plt.figure(0)
            plt.pie(mv_2016_times, labels=mv_2016_title, explode=myexplode, shadow=True, radius=2, autopct='%1.1f%%')
            plt.text(2.5, -1.75, "Most viewed videos by category in 2016", **arialfont);
            st.pyplot()

        elif(add_selectbox_year=="All"):
            st.success("All years")

            plt.rcParams["figure.figsize"] = [7.50, 7.50]
            plt.rcParams["figure.autolayout"] = True

            plt.plot(df_2016.day.value_counts().sort_index(), color='blue', label="2016")
            plt.plot(df_2017.day.value_counts().sort_index(), color='red', label="2017")
            plt.plot(df_2018.day.value_counts().sort_index(), color='green', label="2018")
            plt.plot(df_2019.day.value_counts().sort_index(), color='brown', label="2019")
            plt.plot(df_2020.day.value_counts().sort_index(), color='gray', label="2020")
            plt.plot(df_2021.day.value_counts().sort_index(), color='yellow', label="2021")

            plt.xticks(np.arange(1, 32))
            plt.xlabel("Day")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption through years")
            plt.legend()
            st.pyplot()

            plt.rcParams["figure.autolayout"] = False

            plt.figure(figsize=(25, 15))
            plt.subplot(3, 2, 1)
            plt.bar(np.arange(0, 12), df_2016.hour.value_counts().sort_index(), label="2016")
            plt.xlabel("Hour")
            plt.ylabel("Number of searches made or videos viewed")
            plt.xticks(range(0, 24))
            plt.title("YouTube consumption in 2016")
            plt.legend()

            plt.subplot(3, 2, 2)
            plt.bar(np.arange(0, 8), df_2017.hour.value_counts().sort_index(), color='red', label="2017")
            plt.xlabel("Hour")
            plt.ylabel("Number of searches made or videos viewed")
            plt.xticks(range(0, 24))
            plt.title("YouTube consumption in 2017")
            plt.legend()

            plt.subplot(3, 2, 3)
            plt.bar(np.arange(0, 17), df_2018.hour.value_counts().sort_index(), color='brown', label="2018")
            plt.xticks(range(0, 24))
            plt.xlabel("Hour")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2018")
            plt.legend()

            plt.subplot(3, 2, 4)
            plt.bar(np.arange(0, 21), df_2019.hour.value_counts().sort_index(), color='green', label="2019")
            plt.xticks(range(0, 24))
            plt.xlabel("Hour")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2019")
            plt.legend()

            plt.subplot(3, 2, 5)
            plt.bar(np.arange(0, 20), df_2020.hour.value_counts().sort_index(), color='gray', label="2020")
            plt.xticks(range(0, 24))
            plt.xlabel("Hour")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2020")
            plt.legend()

            plt.subplot(3, 2, 6)
            plt.bar(np.arange(0, 24), df_2021.hour.value_counts().sort_index(), color='yellow', label="2021")
            plt.xticks(range(0, 24))
            plt.xlabel("Hour")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2021")
            plt.legend()
            st.pyplot()

            width=0.1
            st.info("Here we have the number of searches made or videos viewed per hour through years")
            plt.figure(figsize = (25,15))
            plt.subplot(3, 2, 1)
            plt.bar(np.arange(0,6), df_2016.month.value_counts().sort_index(), label="2016")
            plt.xlabel("Month")
            plt.ylabel("Number of searches made or videos viewed")
            plt.xticks(range(0,12), "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())
            plt.title("YouTube consumption in 2016")
            plt.legend()

            plt.subplot(3, 2, 2)
            plt.bar(np.arange(0,4),df_2017.month.value_counts().sort_index(), color='red', label="2017")
            plt.xlabel("Month")
            plt.ylabel("Number of searches made or videos viewed")
            plt.xticks(range(0,12), "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())
            plt.title("YouTube consumption in 2017")
            plt.legend()

            plt.subplot(3, 2, 3)
            plt.bar(np.arange(0,8)-width,df_2018.month.value_counts().sort_index(), color='brown', label="2018")
            plt.xticks(range(0,12), "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())
            plt.xlabel("Month")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2018")
            plt.legend()

            plt.subplot(3, 2, 4)
            plt.bar(np.arange(0,10),df_2019.month.value_counts().sort_index(), color='green',label="2019")
            plt.xticks(range(0,12), "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())
            plt.xlabel("Month")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2019")
            plt.legend()

            plt.subplot(3, 2, 5)
            plt.bar(np.arange(0,12),df_2020.month.value_counts().sort_index(), color='gray', label="2020")
            plt.xticks(range(0,12), "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())
            plt.xlabel("Month")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2020")
            plt.legend()

            plt.subplot(3, 2, 6)
            plt.bar(np.arange(0,9),df_2021.month.value_counts().sort_index(), color='yellow', label="2021")
            plt.xticks(range(0,12), "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split())
            plt.xlabel("Month")
            plt.ylabel("Number of searches made or videos viewed")
            plt.title("YouTube consumption in 2021")
            plt.legend()
            st.pyplot()

            st.info("Here we have the number of searches made or videos viewed per month through years")

            plt.bar(np.arange(0, 7), df.weekday.value_counts().sort_index(), label="All years")
            plt.xlabel("Day of the week")
            plt.ylabel("Number of researches")
            plt.title("Frequency of YouTube researches per day")
            plt.xticks(range(0, 7), "Mon Tue Wed Thur Fri Sat Sun".split())
            plt.legend()
            st.pyplot()
            st.info("So Saturday and Wednesday are the days I spent the most time on YouTube through the last 6 years ")

            plt.bar(np.arange(0, 24), df.hour.value_counts().sort_index(), label="All years")
            plt.xlabel("Hour")
            plt.ylabel("Number of researches")
            plt.xticks(range(0, 24))
            plt.title("Frequency of YouTube researches per hour")
            plt.legend()
            st.pyplot()

    elif(add_selectbox_choice=="Interpretation"):
        st.write("On this page, we will interpret our results according to the different years. First of all, we were able to see in the Analysis section that the more time passed, the more the consumption of YouTube also increased. Let’s put back a screen to remember:")

        df_ttest = pd.DataFrame(df.groupby('year').apply(count_rows), columns=["Researches"])
        sns.lineplot(x="year", y="Researches", data=df_ttest)
        st.pyplot()
        st.caption("                                    Explanation through years")

        st.write("As seen earlier, 2016 was the year I used YouTube the least. Indeed, we can see that the number of searches amounted to "+str(len(df_2016))+" that year.")
        st.write("There are several reasons behind that. First of all, in **2016**, I didn’t use social networks very much. Moreover, during the year I had no phone.")
        st.write("We see that this consumption lasts until **2017** with a 60% decrease.")

        st.write("From that year on, my consumption increases exponentially. We can see that between **2016 and 2018**, the number of searches increased by 258%. The main reason is that I bought myself a new phone.")
        st.write("As I was preparing for my baccalaureate, I was watching a lot of school YouTube videos, as we can see on the pie chart of the same year.")

        st.info("*Yes there is 45.5% from American Entertainment but I needed to rest*")

        st.write("The number of searches continues to increase and reached 179 in 2019.")
        image = Image.open(r'C:\Users\Gwet Karis\Desktop\st_app\image\coronavirus.png')
        st.image(image)

        st.caption("                                    Coronavirus crisis")

        df_test_2020 = df[df.year == 2020]
        mean_2020 = df_test_2020.groupby('hour').apply(count_rows).mean()

        df_test_2019 = df[df.year == 2019]
        mean_2019 = df_test_2019.groupby('hour').apply(count_rows).mean()
        mean_2019_month = df_test_2019.groupby('month').apply(count_rows).max()

        df_test_2021 = df[df.year == 2021]
        max_2021 = df_test_2020.groupby('hour').apply(count_rows).max()
        mean_2021_month = df_test_2021.groupby('month').apply(count_rows).max()

        st.write("Due to the coronavirus crisis, my consumption on YouTube has evolved tremendously. On average, I have performed **"+str(mean_2020)+"** researches per hour this year compared to **"+str(mean_2019)+"** in 2019.")
        st.write("The crisis has left its mark as we can see a 282% increase in the number of searches in 2021 given that my school has imposed distance learning courses on us.")
        st.write("The number of searches carried out even reaches "+str(max_2021)+" in a hour in 2021 !")

        st.write("On average, I watched **"+str(mean_2021_month)+" videos in 2021** compared to **"+str(mean_2019_month)+" in 2019**")
        st.caption("                                    Types of videos")
        st.write("Through this information, we can see what type of people I am. Indeed, despite the years passing, the same types of videos often come back: *Anime*, *Music*, *School*")
        st.info("So if you want to be friends with me, tell me about that!")

        st.write("Finally, we can see that I'm used to see videos around 11 o'clock p.m to 1 p.m, and strongly the night (10 p.m)")
        st.write("We can deduce that I'm a regular person because I don't usually go very late at night on YouTube")
        st.line_chart(df.hour.value_counts().sort_index())
        st.caption("                                    Consumption per hour through years")

        st.write("But we can see through the years than I'm someone who wake-up very early. For example I often watch videos at 10 a.m in 2021")

        st.bar_chart(df_2021.hour.value_counts().sort_index())
        st.caption("                                    Consumption per hour in 2021")

    elif(add_selectbox_choice=="Conclusion"):
        st.title("Conclusion")
        st.write("In conclusion, we can retain 3 elements :\n \nObviously with the time, I'm somebody who consumpted more and more YouTube, almost every hour, every day. However, the main themes of my videos are still the same even 5 years after : US Music, FR Music, School, Manga, Anime.")
        st.write("\nThe day I watch YouTube videos is almost the same in these 5 years, the thursday.")
        st.write("\nThe only thing who is changing is the time which I will watch these videos. In fact, it passed from 10 a.m to 10 p.m. The reason is maybe that when we grow up, we only have more time in the evening and less in the morning")
        st.write("It was a good project because you can see how much time you spend on social media, and how much informations Internet has from you.")
        st.write("I would thank my professor Mr Mathew Mano Joseph for this interesting project, and very concrete.")
        image = Image.open(r'C:\Users\Gwet Karis\Desktop\st_app\image\datascience.jpg')
        st.image(image)
else:
    st.title('About me')
    st.write('Hey ! My name is **KarisG**, I\'m currently in Master 1 Big Data & Artificial Intelligence at **EFREI Paris**, an engineering school.\nYou can find my personal network such as Linkedin https://www.linkedin.com/in/karis-gwet-22906a180/')
    image = Image.open(r'C:\Users\Gwet Karis\Desktop\st_app\image\linkedin.png')
    st.caption("My LinkedIn")
    st.image(image)
    st.write('or my GitHub https://github.com/KarisG')
    image = Image.open(r'C:\Users\Gwet Karis\Desktop\st_app\image\github.png')
    st.image(image)
    st.caption("My GitHub")

    st.write("On this website you'll find the exploratin of my YouTube persnal data, more especially on the history of searches. I decomposed it on three steps :\n* Analysis\n \n* Intrepretation\n \n* Conclusion\n \nIn that way, everyone, even someone who doesn't know anything about data visualization, will be able to see, to understand and to have an opinions on my data.")
    st.write("You can also sumbit your own YouTube personal data (JSON) to see your consumption through years ! For that, use the side box on your left. (*Your data must have the same conditions as mine*)")